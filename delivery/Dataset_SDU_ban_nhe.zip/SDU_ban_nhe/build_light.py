"""Bộ nhỏ: tối đa 12 chu kỳ trải đều theo thời gian cho mỗi pin/giai đoạn.

Chép nguyên văn các dòng nguồn của chu kỳ được chọn. Không cắt ngang chu kỳ.
"""
import csv
import gzip
import hashlib
import json
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
import zipfile
import numpy as np
import pandas as pd

OUT=Path(__file__).resolve().parent
BASE=OUT.parent
FULL=BASE/'selection'
LIMIT=12


def copy_group(record):
    phase,battery,cycles,relative=record
    source=FULL/relative
    output=OUT/relative
    output.parent.mkdir(parents=True,exist_ok=True)
    wanted=set(cycles)
    digest=hashlib.sha256();counts={cycle:0 for cycle in cycles}
    with gzip.open(source,'rb') as original,gzip.open(output,'wb',compresslevel=6) as target:
        header=original.readline()
        columns=next(csv.reader([header.decode('utf-8-sig')]))
        cycle_index=columns.index('Cycle_Index')
        target.write(header);digest.update(header)
        for line in original:
            values=line.split(b',')
            if len(values)!=len(columns):raise ValueError('Cấu trúc dòng CSV không đúng dạng số nguồn')
            cycle=int(float(values[cycle_index]))
            if cycle in wanted:
                target.write(line);digest.update(line);counts[cycle]+=1
    actual=hashlib.sha256()
    with gzip.open(output,'rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):actual.update(block)
    if actual.hexdigest()!=digest.hexdigest():raise ValueError('Không giữ đúng byte nguồn')
    if not all(counts.values()):raise ValueError('Thiếu chu kỳ đã chọn')
    return dict(phase=phase,battery=int(battery),cycles=len(cycles),rows=sum(counts.values()),
                output=relative,uncompressed_sha256=actual.hexdigest(),counts=counts)


def main():
    data=pd.read_csv(FULL/'cycle_features.csv')
    manifest=pd.read_csv(FULL/'source_preservation_audit.csv')
    selected=[]
    for _,part in data.groupby(['phase','battery'],sort=True):
        part=part.sort_values('cycle')
        positions=np.unique(np.linspace(0,len(part)-1,min(LIMIT,len(part))).round().astype(int))
        selected.append(part.iloc[positions])
    chosen=pd.concat(selected,ignore_index=True)
    if chosen.duplicated(['phase','battery','cycle']).any() or chosen.battery.nunique()!=86:
        raise ValueError('Thiếu pin hoặc trùng chu kỳ')
    jobs=[]
    for (phase,battery),part in chosen.groupby(['phase','battery']):
        path=manifest.loc[(manifest.phase==phase)&(manifest.battery==battery),'output'].item()
        jobs.append((phase,int(battery),part.cycle.astype(int).tolist(),path))
    audits=[]
    with ProcessPoolExecutor(max_workers=3) as pool:
        futures=[pool.submit(copy_group,job) for job in jobs]
        for future in as_completed(futures):
            result=future.result()
            for cycle,count in result['counts'].items():
                expected=int(chosen.loc[(chosen.phase==result['phase'])&(chosen.battery==result['battery'])&(chosen.cycle==cycle),'measurement_rows'].item())
                if count!=expected:raise ValueError('Số dòng chu kỳ không khớp bộ đã kiểm chứng')
            audits.append({k:v for k,v in result.items() if k!='counts'})
            if len(audits)%20==0:print('Đã đối chiếu',len(audits),'/',len(jobs),'file',flush=True)
    rows=sum(item['rows'] for item in audits)
    if rows!=int(chosen.measurement_rows.sum()):raise ValueError('Tổng số dòng không khớp')
    summary=json.loads((FULL/'dataset_summary.json').read_text())
    features=summary['feature_columns']
    chosen.to_csv(OUT/'cycle_features.csv',index=False)
    chosen[['battery','phase',*features,'soh_pct']].to_csv(OUT/'training_table.csv',index=False)
    pd.DataFrame(audits).to_csv(OUT/'source_preservation_audit.csv',index=False)
    result=dict(dataset='SDU 2025 — light reference-discharge subset',source_doi=summary['source_doi'],
        original_rows=145112317,parent_selected_rows=30929675,measurement_rows=rows,
        cycles=len(chosen),batteries=int(chosen.battery.nunique()),measurement_files=len(audits),
        max_cycles_per_battery_phase=LIMIT,feature_columns=features,nominal_capacity_ah=2.4,
        min_soh_pct=float(chosen.soh_pct.min()),max_soh_pct=float(chosen.soh_pct.max()),
        phases=chosen.groupby('phase').agg(batteries=('battery','nunique'),cycles=('cycle','size'),rows=('measurement_rows','sum')).reset_index().to_dict('records'),
        reduction_percent=100*(1-rows/30929675),
        rule='Choose <=12 whole cycles evenly spaced by chronological cycle rank in each battery/phase, including first and last eligible cycles. No selection by SOH or model score.',
        all_selected_source_bytes_preserved=True,interpolation=False,replication=False,
        full_source_and_parent_subset_preserved=True,applied_to_application=False)
    (OUT/'dataset_summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    text=f'''# SDU 2025 — bộ nhỏ cho máy cá nhân

- {rows:,} dòng đo xả, {len(chosen):,} chu kỳ, 86 pin vật lý.
- Tối đa 12 chu kỳ nguyên vẹn trên mỗi pin/giai đoạn. Chọn trải đều theo thứ tự chu kỳ, gồm đầu và cuối; không chọn theo giá trị SOH hoặc điểm mô hình.
- Giảm {result['reduction_percent']:.1f}% số dòng so với bộ 30.929.675 dòng. Giảm số mẫu có thể ảnh hưởng sai số và độ ổn định; cần đánh giá mô hình lại, không dùng lại chỉ số của bộ lớn.
- Từng dòng đo, tên cột, mã pin, số chu kỳ và thứ tự nguồn được giữ nguyên văn. Không sửa số đo, điền thiếu, nội suy hay nhân bản. Bộ gốc và bộ 30,9 triệu dòng vẫn giữ riêng.

## File

`source_rows/`: CSV nguồn đã chọn dòng, nén gzip, chia theo giai đoạn và file nguồn. Đây là tập con do dự án tạo, không phải gói gốc tác giả phát hành.

`training_table.csv`: bảng nhỏ để huấn luyện. Đầu vào phải lấy đúng danh sách feature_columns trong dataset_summary.json; đích soh_pct. Battery dùng chia nhóm, không làm đặc trưng.

`cycle_features.csv`: đặc trưng, nhãn và thông tin truy nguồn. Các giá trị này đã được tính từ bộ lựa chọn lớn, không phải cột có sẵn trong CSV nguồn.

`source_preservation_audit.csv`: kiểm đếm và SHA-256 nội dung CSV sau giải nén, được đối chiếu với các byte chọn từ nguồn.

Nguồn: https://zenodo.org/records/14859405 — DOI 10.5281/zenodo.14859405, công bố 12/02/2025, CC BY 4.0. Wang, Gao và Tian: Deep sorting of reused batteries for enabling long-term consistency grouping with unknown prior conditions. Pin NMC(532)/graphite Lishen LR1865SZ, danh định 2,4 Ah.

Bộ này kế thừa điều kiện xả tham chiếu 0,2C từ bộ đã kiểm tra: dòng khoảng -0,48 A, đầu xả >=4 V, cuối xả gần 3 V, có kiểm tra dung lượng và tín hiệu. SOH = dung lượng tham chiếu / 2,4 × 100. Đặc trưng chỉ dùng 120 giây đầu xả; dung lượng toàn chu kỳ dùng làm nhãn, không làm đầu vào.

Hai giai đoạn thuộc cùng 86 pin. Phải chia huấn luyện/kiểm thử theo pin vật lý qua cả hai giai đoạn. Có ít mẫu chu kỳ hơn bộ lớn; đây là lựa chọn giảm quy mô xử lý, không phải bằng chứng chất lượng mô hình được giữ nguyên.

Chạy trên máy 16 GB: đọc từng file hoặc từng khối, huấn luyện bằng training_table.csv; không nạp toàn bộ dữ liệu đo vào RAM. Hiện bộ này chưa được áp dụng vào ứng dụng.
'''
    (OUT/'README.md').write_text(text)
    output=BASE/'Dataset_SDU_ban_nhe.zip'
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as archive:
        for name in ['README.md','dataset_summary.json','cycle_features.csv','training_table.csv','source_preservation_audit.csv','build_light.py']:
            archive.write(OUT/name,'SDU_ban_nhe/'+name)
        for file in sorted((OUT/'source_rows').rglob('*.csv.gz')):
            archive.write(file,'SDU_ban_nhe/'+str(file.relative_to(OUT)),compress_type=zipfile.ZIP_STORED)
    with zipfile.ZipFile(output) as archive:
        if archive.testzip() is not None:raise ValueError('ZIP lỗi')
    checksum=hashlib.sha256(output.read_bytes()).hexdigest()
    output.with_suffix('.sha256').write_text(checksum+'  '+output.name+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)
    print('ZIP',output.stat().st_size,'bytes',flush=True)


if __name__=='__main__':main()
